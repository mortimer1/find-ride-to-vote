
## 0.2.0 — 2015—07-16

* Add vanpool matching functionality.

## 0.1.0 — 2015-07-01

* Precompile es6 with Babel before publishing

## 0.0.2 — 2015-06-29

* Drop node `0.10` support
* Use `from` and `to` from the commuters instead of just `coordinates`. Allows for multi-destination matching in the future.
